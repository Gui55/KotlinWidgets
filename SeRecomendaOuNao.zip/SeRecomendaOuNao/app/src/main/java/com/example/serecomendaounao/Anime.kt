package com.example.serecomendaounao

class Anime(val usuario: String,
            val nome: String,
            val nota: Float,
            val recomenda: Boolean)