package com.example.serecomendaounao

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    companion object{
        public val listAnim = mutableListOf<Anime>()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


    }

    fun submitMethod(view: View) {

        val intent = Intent(this, FormsActivity::class.java)
        intent.putExtra("Nome", enterNome.text.toString())
        intent.putExtra("Nota", enterNota.rating)
        intent.putExtra("Recomendacao", enterToggle.isChecked())

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_layout, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        val intent = Intent(this, FormsActivity::class.java)

        when(item.itemId){

            R.id.itemMenuA -> {

                val recome : Boolean

                if(enterToggle.text.toString()=="Recomendaria"){
                    recome = true
                } else {
                    recome = false
                }

                listAnim.add(
                    Anime(enterUser.text.toString(),
                        enterNome.text.toString(),
                        enterNota.rating.toFloat(),
                        recome)
                )

                startActivity(intent)

            }

            R.id.itemMenuB -> {

                startActivity(intent)

            }

        }

        return super.onOptionsItemSelected(item)

    }
}
