package com.example.serecomendaounao

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import kotlinx.android.synthetic.main.list_item.view.*

class AnimeAdapter(val listaAnimes: List<Anime>,context: Context) : BaseAdapter(){
    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {

        val inflate = LayoutInflater.from(contexto).inflate(R.layout.list_item, p2, false)

        val anime = listA.get(p0)

        inflate.resultUser.setText(anime.usuario)
        inflate.resultRatingBar.setRating(anime.nota)
        inflate.resultText.setText(anime.nome)

        if(anime.recomenda == true){

            inflate.resultRecomenda.setText("Recomenda")

        } else {

            inflate.resultRecomenda.setText("Não recomenda")

        }

        return inflate

    }

    override fun getItem(p0: Int): Any {
        return listA.get(p0)
    }

    override fun getItemId(p0: Int): Long {
        return 0
    }

    override fun getCount(): Int {
        return listA.size
    }

    private val listA = listaAnimes
    private val contexto = context



}